# APEX Store — Google Play Release Preparation v1.0.0+6

تطبيق متجر إلكتروني عربي RTL بعملة الريال السعودي، مع طبقة خادم آمنة بدل التدفقات المحلية الوهمية.

## ما تم تطويره
- تسجيل وإنشاء حسابات حقيقية عبر JWT + PostgreSQL.
- حفظ الطلبات في PostgreSQL.
- التحقق من المنتجات والأسعار والمخزون من الخادم بدل الثقة في إجمالي الهاتف.
- خصم المخزون داخل transaction عند إنشاء الطلب.
- الدفع عند الاستلام: إنشاء طلب حقيقي في قاعدة البيانات.
- Tabby KSA: إنشاء Checkout Session من الخادم وفتح بوابة Tabby، مع Webhook endpoint.
- Tamara KSA: إنشاء Checkout Session من الخادم وفتح رابط Tamara، مع Webhook endpoint.
- PayPal: إنشاء Order من الخادم مع OAuth 2.0 ومسار return/capture.
- عدم وضع مفاتيح الدفع السرية داخل تطبيق Flutter.
- صفحة الطلبات تقرأ الطلبات من الخادم.
- إعدادات دفع منفصلة للحسابات وطرق العملاء.

## ما يلزم قبل الإطلاق
هذه الحزمة أصبحت **قاعدة إطلاق حقيقية** وليست مجرد نموذج واجهة، لكن لا يمكن تشغيل معاملات حقيقية دون بيانات التاجر الخاصة بك. يجب إدخال مفاتيح الإنتاج في `backend/.env`، إعداد PostgreSQL وHTTPS، ثم اجتياز اختبارات واعتماد مزودي الدفع.

### متطلبات الدفع
- **Tabby:** مفتاح Secret + Merchant Code لحساب KSA، ثم QA وتفعيل الإنتاج. يستخدم الخادم `https://api.tabby.sa`.
- **Tamara:** API Token + Notification Token، ثم اختبار/مراجعة sandbox والحصول على اعتماد الإنتاج. يستخدم الخادم `https://api.tamara.co`.
- **PayPal:** حساب Business + Live Client ID/Secret.
- **Google Pay / Visa / Mastercard:** تحتاج بوابة معالجة بطاقات معتمدة تدعم Google Pay؛ لا تتم معالجة بيانات البطاقة الخام داخل Flutter.

## تشغيل الخادم
```bash
cd backend
cp .env.example .env
npm install
npm start
```

للتجربة المحلية يمكن تشغيل PostgreSQL عبر:
```bash
docker compose up -d postgres
```
ثم ضبط `DATABASE_URL=postgresql://apex:change-this-password@localhost:5432/apex`.

## تشغيل Flutter
```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=https://api.example.com
```

قبل نشر Android/iOS نفّذ `flutter analyze` ثم أنشئ مفاتيح توقيع الإصدار النهائي.

## مصادر التكامل الحالية
- Tabby API يستخدم جلسة Checkout وWebhooks، وللسعودية قاعدة API هي `https://api.tabby.sa`. citeturn1search0turn1search1turn1search3
- Tamara Direct Checkout يعيد `order_id` و`checkout_id` و`checkout_url`، ويحتاج API/Notification tokens من حساب التاجر. citeturn2search0turn2search2turn2search5
- PayPal REST يستخدم OAuth 2.0، وتوصي وثائق PayPal بتنفيذ Orders API من الخادم. citeturn0search6turn0search21
- Google Pay يعيد رمز دفع يجب إرساله إلى بوابة/معالج الدفع من الخادم، ويتطلب إعداد إنتاج مناسب. citeturn0search1turn0search13


## Google Play
- Android applicationId: `com.apex.store`
- Target/compile SDK: Android 16 / API 36
- Version: 1.0.0 (versionCode 6)
- Store name: APEX | أبيكس
- Release signing: configure `android/key.properties` with your own upload keystore; never commit secrets.
- This environment does not include the Flutter SDK, so the final AAB must be built and verified on a machine/CI with Flutter + Android SDK 36 installed.
